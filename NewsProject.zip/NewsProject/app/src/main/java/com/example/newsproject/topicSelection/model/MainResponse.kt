package com.example.newsproject.topicSelection.model

data class MainResponse(
    var image:Int,
    var title : String,
    var isChecked:Boolean
)